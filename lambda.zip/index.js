const mysql = require('mysql');

exports.handler = async (event) => {
  // Retrieve data from the event object
  const { data } = event;

  // Create a MySQL connection
  const connection = mysql.createConnection({
    host: 'your-rds-endpoint',
    user: 'your-username',
    password: 'your-password',
    database: 'your-database',
  });

  // Connect to the database
  connection.connect();

  // Insert data into the MySQL table
  const insertQuery = 'INSERT INTO your_table_name (column1, column2) VALUES (?, ?)';
  const values = [data.column1, data.column2];

  connection.query(insertQuery, values, (error, results) => {
    if (error) {
      // Handle the error
      console.error('Error inserting data into MySQL:', error);
      connection.end();
      return {
        statusCode: 500,
        body: 'Error inserting data into MySQL',
      };
    }

    console.log('Data inserted successfully:', results);
    connection.end();

    return {
      statusCode: 200,
      body: 'Data inserted successfully',
    };
  });
};

